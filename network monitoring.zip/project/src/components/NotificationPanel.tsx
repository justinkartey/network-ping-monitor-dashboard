import React, { useState } from 'react';
import { Bell, BellOff, Settings, X, CheckCircle, AlertTriangle, Mail, Smartphone } from 'lucide-react';
import { DowntimeAlert, NotificationSettings } from '../types';

interface NotificationPanelProps {
  alerts: DowntimeAlert[];
  settings: NotificationSettings;
  onAcknowledgeAlert: (ip: string) => void;
  onUpdateSettings: (settings: Partial<NotificationSettings>) => void;
  activeAlertsCount: number;
}

export const NotificationPanel: React.FC<NotificationPanelProps> = ({
  alerts,
  settings,
  onAcknowledgeAlert,
  onUpdateSettings,
  activeAlertsCount
}) => {
  const [showPanel, setShowPanel] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [emailInput, setEmailInput] = useState('');

  const addEmail = () => {
    if (emailInput && !settings.adminEmails.includes(emailInput)) {
      onUpdateSettings({
        adminEmails: [...settings.adminEmails, emailInput]
      });
      setEmailInput('');
    }
  };

  const removeEmail = (email: string) => {
    onUpdateSettings({
      adminEmails: settings.adminEmails.filter(e => e !== email)
    });
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours}h ${remainingMinutes}m`;
  };

  return (
    <div className="relative">
      {/* Notification Bell */}
      <button
        onClick={() => setShowPanel(!showPanel)}
        className={`relative p-2 rounded-lg transition-colors ${
          activeAlertsCount > 0
            ? 'bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900 dark:text-red-300 animate-pulse'
            : 'bg-gray-200 text-gray-600 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300 hover:scale-110'
        }`}
        aria-label="Notifications"
      >
        {activeAlertsCount > 0 ? (
          <Bell className="h-5 w-5 animate-bounce" />
        ) : (
          <BellOff className="h-5 w-5" />
        )}
        
        {activeAlertsCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold animate-pulse">
            {activeAlertsCount > 9 ? '9+' : activeAlertsCount}
          </span>
        )}
      </button>

      {/* Notification Panel */}
      {showPanel && (
        <div className="absolute right-0 top-12 w-96 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 z-50">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                Network Alerts
              </h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <Settings className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setShowPanel(false)}
                  className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
              <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                Notification Settings
              </h4>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Smartphone className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Browser Notifications</span>
                  </div>
                  <button
                    onClick={() => onUpdateSettings({ browserEnabled: !settings.browserEnabled })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.browserEnabled ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.browserEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Mail className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-700 dark:text-gray-300">Email Notifications</span>
                  </div>
                  <button
                    onClick={() => onUpdateSettings({ emailEnabled: !settings.emailEnabled })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings.emailEnabled ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings.emailEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <div>
                  <label className="text-sm text-gray-700 dark:text-gray-300">
                    Alert Threshold (minutes)
                  </label>
                  <input
                    type="number"
                    value={settings.downTimeThreshold}
                    onChange={(e) => onUpdateSettings({ downTimeThreshold: Number(e.target.value) })}
                    className="mt-1 w-full px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                    min="1"
                    max="60"
                  />
                </div>

                {settings.emailEnabled && (
                  <div>
                    <label className="text-sm text-gray-700 dark:text-gray-300">
                      Admin Email Addresses
                    </label>
                    <div className="mt-1 flex space-x-2">
                      <input
                        type="email"
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        placeholder="admin@example.com"
                        className="flex-1 px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
                        onKeyPress={(e) => e.key === 'Enter' && addEmail()}
                      />
                      <button
                        onClick={addEmail}
                        className="px-3 py-1 bg-blue-500 text-white text-sm rounded-md hover:bg-blue-600"
                      >
                        Add
                      </button>
                    </div>
                    <div className="mt-2 space-y-1">
                      {settings.adminEmails.map((email) => (
                        <div key={email} className="flex items-center justify-between bg-gray-100 dark:bg-gray-600 px-2 py-1 rounded">
                          <span className="text-sm text-gray-700 dark:text-gray-300">{email}</span>
                          <button
                            onClick={() => removeEmail(email)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Alerts List */}
          <div className="max-h-96 overflow-y-auto">
            {alerts.length === 0 ? (
              <div className="p-6 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
                <p className="text-gray-500 dark:text-gray-400">All systems operational</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {alerts.map((alert) => (
                  <div
                    key={alert.ip}
                    className={`p-4 ${
                      alert.acknowledged 
                        ? 'bg-gray-50 dark:bg-gray-700 opacity-75' 
                        : 'bg-red-50 dark:bg-red-900/20'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <AlertTriangle className={`h-5 w-5 mt-0.5 ${
                          alert.acknowledged ? 'text-gray-400' : 'text-red-500'
                        }`} />
                        <div>
                          <h4 className={`font-medium ${
                            alert.acknowledged 
                              ? 'text-gray-600 dark:text-gray-400' 
                              : 'text-red-800 dark:text-red-200'
                          }`}>
                            {alert.siteName}
                          </h4>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {alert.ip}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Down for {formatDuration(alert.duration)}
                          </p>
                          <p className="text-xs text-gray-400 dark:text-gray-500">
                            Since {new Date(alert.downSince).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      
                      {!alert.acknowledged && (
                        <button
                          onClick={() => onAcknowledgeAlert(alert.ip)}
                          className="px-3 py-1 bg-blue-500 text-white text-sm rounded-md hover:bg-blue-600"
                        >
                          Acknowledge
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};