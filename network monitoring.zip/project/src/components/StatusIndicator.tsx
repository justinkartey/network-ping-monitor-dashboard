import React from 'react';
import { Circle, Wifi, WifiOff, Clock } from 'lucide-react';
import { getStatusColor, getStatusBadgeColor, getSiteName } from '../utils';

interface StatusIndicatorProps {
  ip: string;
  status: 'up' | 'down' | 'slow';
  latency?: number | null;
  showDetails?: boolean;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({ 
  ip, 
  status, 
  latency, 
  showDetails = false 
}) => {
  const getStatusIcon = () => {
    switch (status) {
      case 'up': return <Wifi className="h-4 w-4" />;
      case 'slow': return <Clock className="h-4 w-4" />;
      case 'down': return <WifiOff className="h-4 w-4" />;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'up': return 'UP';
      case 'slow': return 'SLOW';
      case 'down': return 'DOWN';
    }
  };

  return (
    <div className="flex flex-col space-y-2 transition-all duration-300">
      <div className="flex items-center space-x-2">
        <Circle className={`h-3 w-3 ${getStatusColor(status)} fill-current transition-all duration-300 ${
          status === 'up' ? 'animate-pulse' : status === 'down' ? 'animate-bounce' : ''
        }`} />
        <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">
          {getSiteName(ip)}
        </span>
      </div>
      
      <div className="flex items-center space-x-3">
        <span className="font-mono text-xs text-gray-500 dark:text-gray-400">
          {ip}
        </span>
        
        <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium transition-all duration-300 ${getStatusBadgeColor(status)} ${
          status === 'down' ? 'animate-pulse' : ''
        }`}>
          {getStatusIcon()}
          <span>{getStatusText()}</span>
        </div>
        
        {showDetails && latency !== null && (
          <span className="text-sm text-gray-500 dark:text-gray-400 transition-all duration-300">
            {latency}ms
          </span>
        )}
      </div>
    </div>
  );
};