import React, { useState } from 'react';
import { RefreshCw, Filter, Activity, Server } from 'lucide-react';
import { usePingData } from '../hooks/usePingData';
import { useNotifications } from '../hooks/useNotifications';
import { PingChart } from './PingChart';
import { PingTable } from './PingTable';
import { ThemeToggle } from './ThemeToggle';
import { NotificationPanel } from './NotificationPanel';
import { DashboardFilters } from '../types';
import { getSiteName } from '../utils';

export const Dashboard: React.FC = () => {
  const { 
    groupedData, 
    loading, 
    refreshing, 
    error, 
    lastUpdated, 
    refetch 
  } = usePingData();
  const { 
    alerts, 
    settings, 
    acknowledgeAlert, 
    updateSettings, 
    activeAlertsCount 
  } = useNotifications(groupedData);
  const [showTable, setShowTable] = useState(false);
  const [filters, setFilters] = useState<DashboardFilters>({
    selectedIp: 'all',
    latencyThreshold: 100
  });
  const [autoRefresh, setAutoRefresh] = useState(true);

  const ips = Object.keys(groupedData);
  const filteredIps = filters.selectedIp === 'all' ? ips : [filters.selectedIp];

  const getOverallStats = () => {
    const totalIps = ips.length;
    const upIps = ips.filter(ip => {
      const latestEntry = groupedData[ip]?.[groupedData[ip].length - 1];
      return latestEntry?.status === 'up';
    }).length;
    
    return { totalIps, upIps, downIps: totalIps - upIps };
  };

  const stats = getOverallStats();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-500 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading ping data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Activity className="h-8 w-8 text-blue-500" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                Network Ping Monitor Dashboard
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${refreshing ? 'bg-blue-500 animate-pulse' : 'bg-green-500'}`}></div>
                  <span className="text-gray-600 dark:text-gray-400">
                    {refreshing ? 'Updating...' : 'Live'}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Server className="h-4 w-4 text-green-500" />
                  <span className="text-gray-600 dark:text-gray-400">
                    {stats.upIps}/{stats.totalIps} Online
                  </span>
                </div>
              </div>
              
              <button
                onClick={refetch}
                disabled={refreshing}
                className={`p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-all ${
                  refreshing ? 'animate-spin cursor-not-allowed opacity-50' : 'hover:scale-110'
                }`}
                aria-label="Refresh data"
              >
                <RefreshCw className="h-5 w-5" />
              </button>
              
              <NotificationPanel
                alerts={alerts}
                settings={settings}
                onAcknowledgeAlert={acknowledgeAlert}
                onUpdateSettings={updateSettings}
                activeAlertsCount={activeAlertsCount}
              />
              
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
            <p className="text-red-800 dark:text-red-200">
              <strong>Error:</strong> {error}
            </p>
            <p className="text-red-600 dark:text-red-300 text-sm mt-1">
              Showing mock data for demonstration purposes.
            </p>
          </div>
        )}

        {/* Active Alerts Banner */}
        {activeAlertsCount > 0 && (
          <div className="mb-6 bg-red-100 dark:bg-red-900/30 border-l-4 border-red-500 p-4 rounded-r-lg">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400 animate-pulse" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-800 dark:text-red-200">
                  <strong>Network Alert:</strong> {activeAlertsCount} site{activeAlertsCount > 1 ? 's' : ''} currently down for more than {settings.downTimeThreshold} minutes.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Controls */}
        <div className="mb-8 bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between space-y-4 lg:space-y-0">
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-500" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Filters:</span>
            </div>
            
            <div className="flex flex-col lg:flex-row items-start lg:items-center space-y-3 lg:space-y-0 lg:space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600 dark:text-gray-400">Auto-refresh:</label>
                <button
                  onClick={() => setAutoRefresh(!autoRefresh)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    autoRefresh ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      autoRefresh ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600 dark:text-gray-400">IP Address:</label>
                <select
                  value={filters.selectedIp}
                  onChange={(e) => setFilters(prev => ({ ...prev, selectedIp: e.target.value }))}
                  className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                >
                  <option value="all">All IPs</option>
                  {ips.map(ip => (
                    <option key={ip} value={ip}>{getSiteName(ip)} ({ip})</option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600 dark:text-gray-400">Latency Threshold:</label>
                <input
                  type="number"
                  value={filters.latencyThreshold}
                  onChange={(e) => setFilters(prev => ({ ...prev, latencyThreshold: Number(e.target.value) }))}
                  className="w-20 px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-md text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  min="0"
                  max="1000"
                />
                <span className="text-sm text-gray-500 dark:text-gray-400">ms</span>
              </div>
              
              <button
                onClick={() => setShowTable(!showTable)}
                className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium rounded-md transition-all hover:scale-105 active:scale-95"
              >
                {showTable ? 'Hide Table' : 'Show Table'}
              </button>
            </div>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
          {filteredIps.map(ip => (
            <PingChart
              key={ip}
              ip={ip}
              data={groupedData[ip] || []}
              latencyThreshold={filters.latencyThreshold}
            />
          ))}
        </div>

        {/* Table View */}
        {showTable && (
          <div className="space-y-6">
            {filteredIps.map(ip => (
              <PingTable
                key={`table-${ip}`}
                data={groupedData[ip] || []}
                title={ip}
              />
            ))}
          </div>
        )}

        {/* Footer */}
        <footer className="mt-12 text-center text-sm text-gray-500 dark:text-gray-400">
          <div className="space-y-1">
            <p>
              Last updated: {lastUpdated ? lastUpdated.toLocaleString() : 'Never'}
              {refreshing && <span className="ml-2 text-blue-500 animate-pulse">• Refreshing...</span>}
            </p>
            <div className="flex items-center justify-center space-x-4">
              <span className={`flex items-center space-x-1 ${autoRefresh ? 'text-green-500' : 'text-gray-400'}`}>
                <div className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
                <span>Auto-refresh {autoRefresh ? 'ON' : 'OFF'}</span>
              </span>
              <span>•</span>
              <span>Updates every 30 seconds</span>
            </div>
          </div>
          <p className="mt-1">Network Ping Monitor Dashboard - Real-time monitoring and analytics</p>
        </footer>
      </main>
    </div>
  );
};