import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { PingEntry } from '../types';
import { formatTimestamp, getSiteName } from '../utils';
import { StatusIndicator } from './StatusIndicator';

interface PingChartProps {
  ip: string;
  data: PingEntry[];
  latencyThreshold?: number;
}

export const PingChart: React.FC<PingChartProps> = ({ 
  ip, 
  data, 
  latencyThreshold = 100 
}) => {
  const chartData = data.map(entry => ({
    ...entry,
    displayLatency: entry.latency,
    time: formatTimestamp(entry.timestamp)
  }));

  const latestEntry = data[data.length - 1];
  const currentStatus = latestEntry?.status || 'down';
  const currentLatency = latestEntry?.latency;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
            Time: {label}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Latency: {data.latency ? `${data.latency}ms` : 'No response'}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Status: <span className={`font-medium ${
              data.status === 'up' ? 'text-green-600' : 
              data.status === 'slow' ? 'text-yellow-600' : 'text-red-600'
            }`}>
              {data.status.toUpperCase()}
            </span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:scale-[1.02] border border-gray-200 dark:border-gray-700 group">
      <div className="flex items-center justify-between mb-4">
        <StatusIndicator 
          ip={ip} 
          status={currentStatus} 
          latency={currentLatency}
          showDetails 
        />
      </div>

      <div className="h-72 transition-all duration-300 group-hover:h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
            <XAxis 
              dataKey="time" 
              tick={{ fontSize: 12 }}
              className="text-gray-600 dark:text-gray-400"
            />
            <YAxis 
              tick={{ fontSize: 12 }}
              className="text-gray-600 dark:text-gray-400"
              label={{ value: 'Latency (ms)', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine 
              y={latencyThreshold} 
              stroke="#f59e0b" 
              strokeDasharray="5 5"
              label={{ value: "Threshold", position: "topRight" }}
            />
            <Line
              type="monotone"
              dataKey="displayLatency"
              stroke={ip === '192.168.98.254' ? '#10b981' : '#3b82f6'}
              strokeWidth={3}
              className="transition-all duration-300"
              dot={(props) => {
                const { payload } = props;
                if (payload.latency === null) {
                  return <circle cx={props.cx} cy={props.cy} r={5} fill="#ef4444" stroke="#ef4444" strokeWidth={2} className="animate-pulse" />;
                }
                const color = payload.status === 'up' ? '#10b981' : 
                             payload.status === 'slow' ? '#f59e0b' : '#ef4444';
                return <circle cx={props.cx} cy={props.cy} r={4} fill={color} stroke={color} className="hover:r-6 transition-all" />;
              }}
              connectNulls={false}
              animationDuration={800}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
        <div className="flex items-center justify-between transition-all duration-300">
          <span>Last 24 hours</span>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
              <span>Up</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse"></div>
              <span>Slow</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
              <span>Down</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};