export interface PingData {
  ip: string;
  timestamp: string;
  latency: number | null;
  status: 'up' | 'down' | 'slow';
}

export interface PingEntry {
  _id: string;
  ip: string;
  timestamp: string;
  latency: number | null;
  status: 'up' | 'down' | 'slow';
}

export interface GroupedPingData {
  [ip: string]: PingEntry[];
}

export interface DashboardFilters {
  selectedIp: string;
  latencyThreshold: number;
}

export interface NotificationSettings {
  emailEnabled: boolean;
  browserEnabled: boolean;
  adminEmails: string[];
  downTimeThreshold: number; // in minutes
}

export interface DowntimeAlert {
  ip: string;
  siteName: string;
  downSince: string;
  duration: number; // in minutes
  notificationSent: boolean;
  acknowledged: boolean;
}