import { useState, useEffect, useCallback } from 'react';
import { PingEntry, DowntimeAlert, NotificationSettings } from '../types';
import { getSiteName } from '../utils';

export const useNotifications = (groupedData: { [ip: string]: PingEntry[] }) => {
  const [alerts, setAlerts] = useState<DowntimeAlert[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>({
    emailEnabled: false,
    browserEnabled: true,
    adminEmails: [],
    downTimeThreshold: 4 // 4 minutes
  });

  // Request browser notification permission
  useEffect(() => {
    if (settings.browserEnabled && 'Notification' in window) {
      if (Notification.permission === 'default') {
        Notification.requestPermission();
      }
    }
  }, [settings.browserEnabled]);

  const sendBrowserNotification = useCallback((alert: DowntimeAlert) => {
    if (!settings.browserEnabled || !('Notification' in window) || Notification.permission !== 'granted') {
      return;
    }

    new Notification(`Site Down Alert: ${alert.siteName}`, {
      body: `${alert.siteName} (${alert.ip}) has been down for ${alert.duration} minutes`,
      icon: '/favicon.ico',
      tag: `downtime-${alert.ip}`,
      requireInteraction: true
    });
  }, [settings.browserEnabled]);

  const sendEmailNotification = useCallback(async (alert: DowntimeAlert) => {
    if (!settings.emailEnabled || settings.adminEmails.length === 0) {
      return;
    }

    try {
      // In a real implementation, this would call your backend API
      // For demo purposes, we'll just log the email that would be sent
      console.log('Email notification would be sent:', {
        to: settings.adminEmails,
        subject: `URGENT: Site Down Alert - ${alert.siteName}`,
        body: `
          NETWORK MONITORING ALERT
          
          Site: ${alert.siteName}
          IP Address: ${alert.ip}
          Status: DOWN
          Down Since: ${new Date(alert.downSince).toLocaleString()}
          Duration: ${alert.duration} minutes
          
          Please investigate immediately.
          
          Network Monitoring System
        `
      });

      // Simulate API call
      await fetch('/api/send-notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'email',
          alert,
          recipients: settings.adminEmails
        })
      }).catch(() => {
        // Fail silently for demo - in production, implement proper error handling
      });
    } catch (error) {
      console.error('Failed to send email notification:', error);
    }
  }, [settings.emailEnabled, settings.adminEmails]);

  const checkForDowntime = useCallback(() => {
    const now = new Date();
    const newAlerts: DowntimeAlert[] = [];

    Object.entries(groupedData).forEach(([ip, entries]) => {
      if (entries.length === 0) return;

      // Sort entries by timestamp
      const sortedEntries = [...entries].sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );

      // Find consecutive down entries
      let downStart: Date | null = null;
      let consecutiveDownCount = 0;

      for (let i = sortedEntries.length - 1; i >= 0; i--) {
        const entry = sortedEntries[i];
        if (entry.status === 'down') {
          consecutiveDownCount++;
          downStart = new Date(entry.timestamp);
        } else {
          break;
        }
      }

      if (consecutiveDownCount > 0 && downStart) {
        const downDuration = (now.getTime() - downStart.getTime()) / (1000 * 60); // minutes
        
        if (downDuration >= settings.downTimeThreshold) {
          const existingAlert = alerts.find(alert => alert.ip === ip);
          
          if (!existingAlert) {
            const newAlert: DowntimeAlert = {
              ip,
              siteName: getSiteName(ip),
              downSince: downStart.toISOString(),
              duration: Math.floor(downDuration),
              notificationSent: false,
              acknowledged: false
            };
            newAlerts.push(newAlert);
          } else {
            // Update duration for existing alert
            existingAlert.duration = Math.floor(downDuration);
          }
        }
      }
    });

    // Send notifications for new alerts
    newAlerts.forEach(alert => {
      sendBrowserNotification(alert);
      sendEmailNotification(alert);
      alert.notificationSent = true;
    });

    // Update alerts state
    setAlerts(prevAlerts => {
      const updatedAlerts = [...prevAlerts];
      
      // Add new alerts
      newAlerts.forEach(newAlert => {
        if (!updatedAlerts.find(alert => alert.ip === newAlert.ip)) {
          updatedAlerts.push(newAlert);
        }
      });

      // Remove alerts for sites that are back up
      return updatedAlerts.filter(alert => {
        const latestEntry = groupedData[alert.ip]?.[groupedData[alert.ip].length - 1];
        return latestEntry?.status === 'down';
      });
    });
  }, [groupedData, settings.downTimeThreshold, alerts, sendBrowserNotification, sendEmailNotification]);

  // Check for downtime every minute
  useEffect(() => {
    checkForDowntime();
    const interval = setInterval(checkForDowntime, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [checkForDowntime]);

  const acknowledgeAlert = useCallback((ip: string) => {
    setAlerts(prevAlerts =>
      prevAlerts.map(alert =>
        alert.ip === ip ? { ...alert, acknowledged: true } : alert
      )
    );
  }, []);

  const updateSettings = useCallback((newSettings: Partial<NotificationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  return {
    alerts,
    settings,
    acknowledgeAlert,
    updateSettings,
    activeAlertsCount: alerts.filter(alert => !alert.acknowledged).length
  };
};