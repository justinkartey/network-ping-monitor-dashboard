import { useState, useEffect } from 'react';
import { PingEntry, GroupedPingData } from '../types';

// Mock data for development - replace with actual API call
const generateMockData = (): PingEntry[] => {
  const ips = [
    '192.168.98.254',   // PRIMARY
    '192.168.100.254',  // OSU MAIN SITE
    '192.168.101.254',  // TRUST SAKUMONO SITE
    '192.168.102.254',  // TRUST TEMA SITE
    '192.168.103.254',  // TRUST ADENTA SITE
    '192.168.104.254',  // TRUST DOME SITE
    '192.168.105.254',  // TRUST SPECIALIST SITE
    '192.168.107.254',  // TRUST MOTHER & CHILD SITE
    '192.168.109.254'   // TRUST TOWERS SITE
  ];
  const data: PingEntry[] = [];
  
  const now = new Date();
  
  ips.forEach(ip => {
    for (let i = 23; i >= 0; i--) {
      const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000).toISOString();
      let latency: number | null = null;
      let status: 'up' | 'down' | 'slow' = 'down';
      
      // Simulate some realistic ping patterns
      if (Math.random() > 0.1) { // 90% uptime
        latency = Math.floor(Math.random() * 50) + 5;
        if (ip === '192.168.98.254') latency = Math.floor(Math.random() * 10) + 2; // PRIMARY - fastest
        if (ip.startsWith('192.168.10')) latency = Math.floor(Math.random() * 30) + 10; // Trust sites
        
        // Simulate occasional downtime for demonstration
        if (Math.random() < 0.05) { // 5% chance of downtime
          latency = null;
          status = 'down';
        } else {
          status = latency > 100 ? 'slow' : 'up';
        }
      }
      
      // Simulate extended downtime for one site occasionally (for testing notifications)
      if (ip === '192.168.102.254' && i < 6) { // TRUST TEMA SITE down for last 6 hours
        latency = null;
        status = 'down';
      }
      
      data.push({
        _id: `${ip}-${i}`,
        ip,
        timestamp,
        latency,
        status
      });
    }
  });
  
  return data;
};

export const usePingData = (serverAddress: string = 'localhost:3000') => {
  const [data, setData] = useState<PingEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchData = async () => {
    try {
      if (data.length === 0) {
        setLoading(true);
      } else {
        setRefreshing(true);
      }
      setError(null);
      
      // For demo purposes, use mock data. In production, uncomment the fetch call below:
      
      // const response = await fetch(`http://${serverAddress}/ping-data`);
      // if (!response.ok) throw new Error('Failed to fetch ping data');
      // const result = await response.json();
      // setData(result);
      
      // Mock data with realistic delay
      await new Promise(resolve => setTimeout(resolve, data.length === 0 ? 1000 : 500));
      const mockData = generateMockData();
      setData(mockData);
      setLastUpdated(new Date());
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      // Fallback to mock data on error
      setData(generateMockData());
      setLastUpdated(new Date());
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
    // Refresh data every 30 seconds
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [serverAddress]);

  const groupedData: GroupedPingData = data.reduce((acc, entry) => {
    if (!acc[entry.ip]) acc[entry.ip] = [];
    acc[entry.ip].push(entry);
    return acc;
  }, {} as GroupedPingData);

  return { 
    data, 
    groupedData, 
    loading, 
    refreshing,
    error, 
    lastUpdated,
    refetch: fetchData 
  };
};