import { format } from 'date-fns';

export const formatTimestamp = (timestamp: string): string => {
  return format(new Date(timestamp), 'HH:mm');
};

export const formatDate = (timestamp: string): string => {
  return format(new Date(timestamp), 'MMM dd, HH:mm');
};

export const getStatusColor = (status: 'up' | 'down' | 'slow'): string => {
  switch (status) {
    case 'up': return 'text-green-500';
    case 'slow': return 'text-yellow-500';
    case 'down': return 'text-red-500';
    default: return 'text-gray-500';
  }
};

export const getStatusBadgeColor = (status: 'up' | 'down' | 'slow'): string => {
  switch (status) {
    case 'up': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    case 'slow': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    case 'down': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
  }
};

export const getCurrentStatus = (latency: number | null): 'up' | 'down' | 'slow' => {
  if (latency === null) return 'down';
  if (latency > 100) return 'slow';
  return 'up';
};

export const getSiteName = (ip: string): string => {
  const siteMap: { [key: string]: string } = {
    '192.168.98.254': 'PRIMARY',
    '192.168.100.254': 'OSU MAIN SITE',
    '192.168.101.254': 'TRUST SAKUMONO SITE',
    '192.168.102.254': 'TRUST TEMA SITE',
    '192.168.103.254': 'TRUST ADENTA SITE',
    '192.168.104.254': 'TRUST DOME SITE',
    '192.168.105.254': 'TRUST SPECIALIST SITE',
    '192.168.107.254': 'TRUST MOTHER & CHILD SITE',
    '192.168.109.254': 'TRUST TOWERS SITE'
  };
  
  return siteMap[ip] || ip;
}